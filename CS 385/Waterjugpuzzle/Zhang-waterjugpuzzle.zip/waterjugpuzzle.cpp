/*******************************************************************************
 * Name        : waterjugpuzzle.cpp
 * Author      : Zhiyuan(James) Zhang
 * Date        : March 7 2016
 * Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
 * 				 ------James Zhang
 ******************************************************************************/

#include <iostream>
#include <vector>
#include <queue>
#include <sstream>

using namespace std;

int cap_A, cap_B, cap_C, goal_A, goal_B, goal_C;

class State {
public:
	State(int a, int b, int c, const State *prev, char from, char to,
			int volumn) :
			a_(a), b_(b), c_(c), previous(prev), from(from), to(to), v(volumn) {
	}
	;
	State(int a, int b, int c) :
			a_(a), b_(b), c_(c), previous(NULL), from(0), to(0), v(0) {
	}
	;

	int get_A() const {
		return a_;
	}
	int get_B() const {
		return b_;
	}
	int get_C() const {
		return c_;
	}
	char get_from() const {
		return from;
	}
	char get_to() const {
		return to;
	}
	int get_volumn() const {
		return v;
	}
	const State *getPrev() const {
		return previous;
	}

	/*
	 * check if we have been somewhere before,
	 * using that we mark true when we see two of states are equal.
	 */
	bool equals(State &another) const {
		if (a_ == another.get_A() && b_ == another.get_B()
				&& c_ == another.get_C()) {
			return true;
		}
		return false;
	}

private:
	int a_, b_, c_;
	// the previous state that reaches this state in bfs order
	// Which means: Pour (v) gallons from (from) to (to).
	const State *previous;
	char from, to;
	int v;
};

/*
 * now we make a function to check if the state is visited before
 */

bool checkforvisit(State *current, vector<State *> &visit) {
	for (vector<State *>::iterator it = visit.begin(); it != visit.end();
			it++) {
		State *state=*it;
		if (state->equals(*current)) {
			return true;
		}
	}
	return false;
}

/*
 * now let's check if the current state is the same as the goal
 */

bool checkforgoal(State *goal, State *current) {
	return goal->equals(*current);

}

/*
 * then make a bfs for pour
 */

State *pour(State *current, State*goal) {
	vector<State *> visit;
	queue<State *> queue;
	queue.push(current);

	while (!(queue.empty())) {
		current = queue.front();
		queue.pop();

		/*
		 * to check if the goal appears.
		 */
		if (checkforgoal(goal, current)) {
			return current;
		}

		/*
		 * check for visited
		 */
		if (checkforvisit(current, visit)) {
			continue;
		}
		visit.push_back(current);

		if (current->get_C() != 0 && current->get_A() < cap_A) {
			/*
			 * then let's pour from c to a
			 */
			State *temp = new State(
					min(cap_A, current->get_A() + current->get_C()),
					current->get_B(),
					max(0, current->get_A() + current->get_C() - cap_A),
					current, 'C', 'A',
					min(cap_A, current->get_A() + current->get_C())
							- current->get_A());
			queue.push(temp);
		}

		if (current->get_B() != 0 && current->get_A() < cap_A) {
			// pour from B to A
			State *temp = new State(
					min(cap_A, current->get_A() + current->get_B()),
					max(0, current->get_A() + current->get_B() - cap_A),
					current->get_C(), current, 'B', 'A',
					min(cap_A, current->get_A() + current->get_B())
							- current->get_A());
			queue.push(temp);
		}

		if (current->get_C() != 0 && current->get_B() < cap_B) {
			// pour from C to B
			State *temp = new State(current->get_A(),
					min(cap_B, current->get_B() + current->get_C()),
					max(0, current->get_B() + current->get_C() - cap_B),
					current, 'C', 'B',
					min(cap_B, current->get_B() + current->get_C())
							- current->get_B());
			queue.push(temp);
		}

		if (current->get_A() != 0 && current->get_B() < cap_B) {
			// pour from A to B
			State *temp = new State(
					max(0, current->get_B() + current->get_A() - cap_B),
					min(cap_B, current->get_B() + current->get_A()),
					current->get_C(), current, 'A', 'B',
					min(cap_B, current->get_B() + current->get_A())
							- current->get_B());
			queue.push(temp);
		}

		if (current->get_B() != 0 && current->get_C() < cap_C) {
			// pour from B to C
			State *temp = new State(current->get_A(),
					max(0, current->get_C() + current->get_B() - cap_C),
					min(cap_C, current->get_C() + current->get_B()), current,
					'B', 'C',
					min(cap_C, current->get_C() + current->get_B())
							- current->get_C());
			queue.push(temp);
		}

		if (current->get_A() != 0 && current->get_C() < cap_C) {
			// pour from A to C
			State *temp = new State(
					max(0, current->get_C() + current->get_A() - cap_C),
					current->get_B(),
					min(cap_C, current->get_C() + current->get_A()), current,
					'A', 'C',
					min(cap_C, current->get_C() + current->get_A())
							- current->get_C());
			queue.push(temp);
		}
	}

	return NULL;
}

void display(const State*state) {
	if (state->getPrev() != NULL) {
		display(state->getPrev());

		cout << "Pour" << state->get_volumn();
		if (state->get_volumn() > 1) {
			cout << " gallons ";

		} else {
			cout << " gallon ";
		}
		cout << "from " << state->get_from() << " " << "to " << state->get_to()
				<< ".";
	} else {
		cout << "Initial state.";
	}

	cout << "(" << state->get_A() << ", " << state->get_B() << ", "
			<< state->get_C() << ")" << endl;
}

int main(int argc, char * const argv[]) {
	if (argc != 7)
		cerr << "Usage: ./waterjugpuzzle <cap A> <cap B> <cap C> <goal A> "
				"<goal B> <goal C>" << endl;
	else {
		istringstream iss1(argv[1]);
		if (!(iss1 >> cap_A)) {
			cerr << "Error: Invalid capacity '" << argv[1] << "' for jug A."
					<< endl;
			return 1;
		}
		istringstream iss2(argv[2]);
		if (!(iss2 >> cap_B)) {
			cerr << "Error: Invalid capacity '" << argv[2] << "' for jug B."
					<< endl;
			return 1;
		}

		istringstream iss3(argv[3]);
		if (!(iss3 >> cap_C)) {
			cerr << "Error: Invalid capacity '" << argv[3] << "' for jug C."
					<< endl;
			return 1;
		}

		istringstream iss4(argv[1]);
		if (cap_A <= 0) {
			cerr << "Error: Invalid capacity '" << argv[1] << "' for jug A."
					<< endl;
			return 1;
		}
		istringstream iss5(argv[2]);
		if (cap_B <= 0) {
			cerr << "Error: Invalid capacity '" << argv[2] << "' for jug B."
					<< endl;
			return 1;
		}
		istringstream iss6(argv[3]);
		if (cap_C <= 0) {
			cerr << "Error: Invalid capacity '" << argv[3] << "' for jug C."
					<< endl;
			return 1;
		}
		istringstream iss7(argv[4]);
		if (!(iss7 >> cap_C)) {
			cerr << "Error: Invalid goal '" << argv[4] << "' for jug A."
					<< endl;
			return 1;
		}
		istringstream iss8(argv[4]);
		if (cap_A <= 0) {
			cerr << "Error: Invalid goal '" << argv[4] << "' for jug A."
					<< endl;
			return 1;
		}
		istringstream iss9(argv[5]);
		if (!(iss9 >> cap_C)) {
			cerr << "Error: Invalid goal '" << argv[5] << "' for jug B."
					<< endl;
			return 1;
		}
		istringstream iss10(argv[5]);
		if (cap_A <= 0) {
			cerr << "Error: Invalid goal '" << argv[5] << "' for jug B."
					<< endl;
			return 1;
		}
		istringstream iss11(argv[6]);
		if (!(iss11 >> cap_C)) {
			cerr << "Error: Invalid goal '" << argv[6] << "' for jug C."
					<< endl;
			return 1;
		}
		istringstream iss12(argv[6]);
		if (cap_A <= 0) {
			cerr << "Error: Invalid goal '" << argv[6] << "' for jug C."
					<< endl;
			return 1;
		}
		if (goal_A > cap_A) {
			cerr << "Error: Goal cannot exceed capacity of jug A." << endl;
			return 1;
		}

		if (goal_B > cap_B) {
			cerr << "Error: Goal cannot exceed capacity of jug B." << endl;
			return 1;
		}
		if (goal_C > cap_C) {
			cerr << "Error: Goal cannot exceed capacity of jug C." << endl;
			return 1;
		}
		if ((goal_A + goal_B + goal_C) != cap_C) {
			cerr << "Error: Total gallons in goal state must be equal to the "
					"capacity of jug C." << endl;
			return 1;
		}

		State initial_state(0, 0, cap_C);
		State goal(goal_A, goal_B, goal_C);

		State *result = pour(&initial_state, &goal);

		if (result != NULL) {
			display (result);
		}
		else
		{
			cout << "No solution."<<endl;
		}
		return 0;
	}
}
